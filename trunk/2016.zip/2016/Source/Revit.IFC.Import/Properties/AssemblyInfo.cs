using System.Reflection;

// General Information about an assembly is controlled through the following 
// set of attributes. Change these attribute values to modify the information
// associated with an assembly.
[assembly: AssemblyTitle("IFC Import for Revit")]
[assembly: AssemblyDescription("")]
[assembly: AssemblyConfiguration("")]
[assembly: AssemblyCompany("Autodesk, Inc.")]
[assembly: AssemblyProduct("IFC Import for Revit")]
[assembly: AssemblyCopyright("� 2015 Autodesk, Inc. All rights reserved.")]
[assembly: AssemblyTrademark("")]
[assembly: AssemblyCulture("")]

[assembly: AssemblyVersion("16.3.0.0")]
[assembly: AssemblyFileVersion("16.3.0.0")]

#region Using directives

#endregion